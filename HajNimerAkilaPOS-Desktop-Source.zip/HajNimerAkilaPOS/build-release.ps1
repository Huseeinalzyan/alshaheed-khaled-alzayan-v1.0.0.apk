$ErrorActionPreference = 'Stop'
Set-Location "$PSScriptRoot\DesktopPOS"
dotnet restore
dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o .\publish
Write-Host "تم إنشاء EXE داخل: $PWD\publish\HajNimerAkilaPOS.exe" -ForegroundColor Green
