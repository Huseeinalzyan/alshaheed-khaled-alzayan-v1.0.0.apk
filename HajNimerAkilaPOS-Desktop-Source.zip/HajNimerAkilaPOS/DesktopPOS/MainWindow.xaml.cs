using System.Printing;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Documents;
using HajNimerAkilaPOS.Models;
using HajNimerAkilaPOS.Services;

namespace HajNimerAkilaPOS;

public partial class MainWindow : Window
{
    private readonly DatabaseService _db = new(App.DatabasePath);
    private readonly List<CartLine> _cart = new();
    private List<Product> _products = new();
    private string _category = "الكل";
    private decimal Subtotal => _cart.Sum(x => x.Product.Price * x.Quantity);
    private decimal Discount => decimal.TryParse(DiscountBox.Text, out var d) ? Math.Max(0, d) : 0;
    private decimal Total => Math.Max(0, Subtotal - Discount);
    public MainWindow()
    {
        InitializeComponent();
        try { _db.Initialize(); _products = _db.Products(); BuildCategories(); BuildProducts(); UpdateCart(); }
        catch (Exception ex) { MessageBox.Show($"تعذر فتح قاعدة البيانات:\n{ex.Message}", "خطأ", MessageBoxButton.OK, MessageBoxImage.Error); }
        Loaded += (_, _) => ShowLogin();
    }
    private void ShowLogin()
    {
        var login = new LoginWindow(_db) { Owner = this };
        if (login.ShowDialog() != true) Close(); else UserText.Text = $"المستخدم: {login.Username}";
    }
    private void BuildCategories()
    {
        CategoryPanel.Children.Clear(); foreach (var name in new[]{"الكل","فلافل","حمص","فول","فراشيح","بيتا","سندويشات","وجبات","مقبلات","إضافات","مشروبات","أخرى"}) { var b=new Button{Content=name,Tag=name,Padding=new Thickness(14,7,14,7)}; b.Click+=(_,_)=>{_category=(string)b.Tag;BuildProducts();}; CategoryPanel.Children.Add(b); }
    }
    private void BuildProducts()
    {
        ProductPanel.Children.Clear(); var q=SearchBox.Text.Trim(); foreach(var p in _products.Where(p=>p.Active && (_category=="الكل"||p.Category==_category) && (q==""||p.Name.Contains(q)))) { var b=new Button{Width=150,Height=105,Margin=new Thickness(5),Background=new SolidColorBrush(Color.FromRgb(255,255,255)),Content=$"{p.Name}\n{p.Price:0.00} ₪\n{p.Category}"}; b.Click+=(_,_)=>AddToCart(p); ProductPanel.Children.Add(b); }
    }
    private void AddToCart(Product p){var i=_cart.FindIndex(x=>x.Product.Id==p.Id);if(i>=0)_cart[i]=_cart[i] with {Quantity=_cart[i].Quantity+1};else _cart.Add(new CartLine(p,1));UpdateCart();}
    private void UpdateCart(){CartPanel.Children.Clear();foreach(var line in _cart){var row=new DockPanel{Margin=new Thickness(0,5,0,5)};var text=new TextBlock{Text=$"{line.Product.Name}\n{line.Quantity} × {line.Product.Price:0.00} ₪",Width=165};DockPanel.SetDock(text,Dock.Left);row.Children.Add(text);var minus=new Button{Content="−",Padding=new Thickness(7,2,7,2)};minus.Click+=(_,_)=>{var i=_cart.FindIndex(x=>x.Product.Id==line.Product.Id);if(line.Quantity<=1)_cart.RemoveAt(i);else _cart[i]=line with {Quantity=line.Quantity-1};UpdateCart();};row.Children.Add(minus);CartPanel.Children.Add(row);}CartCount.Text=$"{_cart.Sum(x=>x.Quantity)} أصناف";SubtotalText.Text=$"{Subtotal:0.00} ₪";TotalText.Text=$"{Total:0.00} ₪";}
    private void SaveInvoice_Click(object sender,RoutedEventArgs e){if(_cart.Count==0){MessageBox.Show("أضف صنفًا أولًا.");return;}try{_db.SaveInvoice(_cart,Discount,(PaymentBox.SelectedItem as ComboBoxItem)?.Content?.ToString()??"نقدي",UserText.Text);MessageBox.Show("تم حفظ الفاتورة في قاعدة البيانات.","نجاح",MessageBoxButton.OK,MessageBoxImage.Information);_cart.Clear();DiscountBox.Text="0";UpdateCart();}catch(Exception ex){MessageBox.Show($"فشل حفظ الفاتورة: {ex.Message}","خطأ",MessageBoxButton.OK,MessageBoxImage.Error);}}
    private void Print_Click(object sender,RoutedEventArgs e){if(_cart.Count==0){MessageBox.Show("السلة فارغة.");return;}var dlg=new PrintDialog();if(dlg.ShowDialog()!=true)return;var doc=new FlowDocument{PageWidth=dlg.PrintableAreaWidth,FontFamily=new FontFamily("Arial"),FontSize=12,FlowDirection=FlowDirection.RightToLeft};doc.Blocks.Add(new Paragraph(new Run("مطاعم الحاج نمر عكيلة\nخانيونس - دوار الأقصى")){TextAlignment=TextAlignment.Center});foreach(var l in _cart)doc.Blocks.Add(new Paragraph(new Run($"{l.Product.Name}   {l.Quantity} × {l.Product.Price:0.00} ₪   = {(l.Product.Price*l.Quantity):0.00} ₪")));doc.Blocks.Add(new Paragraph(new Run($"الإجمالي: {Total:0.00} ₪\nطريقة الدفع: {(PaymentBox.SelectedItem as ComboBoxItem)?.Content}")));dlg.PrintDocument(((IDocumentPaginatorSource)doc).DocumentPaginator,"فاتورة مطاعم الحاج نمر عكيلة");}
    private void DiscountBox_TextChanged(object s,TextChangedEventArgs e){if(IsInitialized)UpdateCart();} private void SearchBox_TextChanged(object s,TextChangedEventArgs e){if(IsInitialized)BuildProducts();} private void Search_Click(object s,RoutedEventArgs e)=>BuildProducts(); private void NewInvoice_Click(object s,RoutedEventArgs e){_cart.Clear();DiscountBox.Text="0";UpdateCart();} private void Products_Click(object s,RoutedEventArgs e)=>MessageBox.Show("إدارة الأصناف متاحة عبر قاعدة البيانات في هذا الإصدار الأساسي. يمكن إضافة شاشة الإدارة التالية."); private void Invoices_Click(object s,RoutedEventArgs e)=>MessageBox.Show(string.Join("\n",_db.Invoices().Take(15).Select(x=>$"{x.Number} | {x.Total:0.00} ₪ | {x.PaymentMethod}")),"الفواتير السابقة"); private void Reports_Click(object s,RoutedEventArgs e)=>MessageBox.Show($"عدد الفواتير: {_db.Invoices().Count}\nإجمالي المبيعات: {_db.Invoices().Sum(x=>x.Total):0.00} ₪","التقارير"); private void Printer_Click(object s,RoutedEventArgs e)=>Print_Click(s,e); private void Backup_Click(object s,RoutedEventArgs e){var dlg=new Microsoft.Win32.SaveFileDialog{Filter="SQLite Database|*.db",FileName=$"backup-{DateTime.Now:yyyyMMdd-HHmm}.db"};if(dlg.ShowDialog()==true)File.Copy(App.DatabasePath,dlg.FileName,true);} private void Logout_Click(object s,RoutedEventArgs e){ShowLogin();}
}
