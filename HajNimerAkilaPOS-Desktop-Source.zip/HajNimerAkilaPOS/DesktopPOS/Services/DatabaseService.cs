using Microsoft.Data.Sqlite;
using HajNimerAkilaPOS.Models;

namespace HajNimerAkilaPOS.Services;

public sealed class DatabaseService
{
    private readonly string _connectionString;
    public DatabaseService(string path) => _connectionString = $"Data Source={path};Mode=ReadWriteCreate;Cache=Shared";
    private SqliteConnection Open() { var c = new SqliteConnection(_connectionString); c.Open(); return c; }
    public void Initialize()
    {
        using var c = Open(); using var cmd = c.CreateCommand();
        cmd.CommandText = @"
CREATE TABLE IF NOT EXISTS Users(Id INTEGER PRIMARY KEY AUTOINCREMENT, Username TEXT NOT NULL UNIQUE, PasswordHash TEXT NOT NULL, Role TEXT NOT NULL, CreatedAt TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS Categories(Id INTEGER PRIMARY KEY AUTOINCREMENT, Name TEXT NOT NULL UNIQUE);
CREATE TABLE IF NOT EXISTS Products(Id INTEGER PRIMARY KEY AUTOINCREMENT, Name TEXT NOT NULL, Category TEXT NOT NULL, Price REAL NOT NULL, Active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS Invoices(Id INTEGER PRIMARY KEY AUTOINCREMENT, Number TEXT NOT NULL UNIQUE, CreatedAt TEXT NOT NULL, Cashier TEXT NOT NULL, Subtotal REAL NOT NULL, Discount REAL NOT NULL, Total REAL NOT NULL, PaymentMethod TEXT NOT NULL, Status TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS InvoiceItems(Id INTEGER PRIMARY KEY AUTOINCREMENT, InvoiceId INTEGER NOT NULL, ProductId INTEGER NOT NULL, Name TEXT NOT NULL, Quantity INTEGER NOT NULL, UnitPrice REAL NOT NULL);
"; cmd.ExecuteNonQuery();
        using var tx = c.BeginTransaction();
        var seed = c.CreateCommand(); seed.Transaction = tx; seed.CommandText = "INSERT OR IGNORE INTO Users(Username,PasswordHash,Role,CreatedAt) VALUES('admin',@hash,'Admin',@now);"; seed.Parameters.AddWithValue("@hash", BCrypt.Net.BCrypt.HashPassword("10203090")); seed.Parameters.AddWithValue("@now", DateTime.UtcNow.ToString("O")); seed.ExecuteNonQuery();
        foreach (var cat in new[]{"فلافل","حمص","فول","فراشيح","بيتا","سندويشات","وجبات","مقبلات","إضافات","مشروبات","أخرى"}) { using var q=c.CreateCommand(); q.Transaction=tx; q.CommandText="INSERT OR IGNORE INTO Categories(Name) VALUES(@n)"; q.Parameters.AddWithValue("@n",cat); q.ExecuteNonQuery(); }
        if (Products().Count == 0) foreach (var p in new[]{new Product(0,"فلافل","فلافل",2),new Product(0,"سندويش فلافل","سندويشات",4),new Product(0,"حمص","حمص",5),new Product(0,"فول","فول",5),new Product(0,"فراشيح","فراشيح",7),new Product(0,"بيتا","بيتا",3),new Product(0,"وجبة فلافل","وجبات",12),new Product(0,"بطاطا","مقبلات",6),new Product(0,"مخلل","إضافات",2),new Product(0,"مشروب غازي","مشروبات",3)}) AddProduct(p, c, tx);
        tx.Commit();
    }
    public bool ValidateLogin(string username, string password) { using var c=Open(); using var q=c.CreateCommand(); q.CommandText="SELECT PasswordHash FROM Users WHERE Username=@u"; q.Parameters.AddWithValue("@u",username); var hash=q.ExecuteScalar()?.ToString(); return hash is not null && BCrypt.Net.BCrypt.Verify(password,hash); }
    public List<Product> Products() { using var c=Open(); return ReadProducts(c, null); }
    private static List<Product> ReadProducts(SqliteConnection c, SqliteTransaction? tx) { using var q=c.CreateCommand(); q.Transaction=tx; q.CommandText="SELECT Id,Name,Category,Price,Active FROM Products ORDER BY Category,Name"; using var r=q.ExecuteReader(); var list=new List<Product>(); while(r.Read()) list.Add(new Product(r.GetInt64(0),r.GetString(1),r.GetString(2),Convert.ToDecimal(r.GetDouble(3)),r.GetInt64(4)==1)); return list; }
    public void AddProduct(Product p) { using var c=Open(); AddProduct(p,c,null); }
    private static void AddProduct(Product p, SqliteConnection c, SqliteTransaction? tx) { using var q=c.CreateCommand(); q.Transaction=tx; q.CommandText="INSERT INTO Products(Name,Category,Price,Active) VALUES(@n,@cat,@p,1)"; q.Parameters.AddWithValue("@n",p.Name); q.Parameters.AddWithValue("@cat",p.Category); q.Parameters.AddWithValue("@p",p.Price); q.ExecuteNonQuery(); }
    public long SaveInvoice(IReadOnlyList<CartLine> lines, decimal discount, string payment, string cashier)
    {
        using var c=Open(); using var tx=c.BeginTransaction(); var id=DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(); var number=$"INV-{id % 1000000:000000}"; var subtotal=lines.Sum(x=>x.Product.Price*x.Quantity); var total=Math.Max(0,subtotal-discount);
        using(var q=c.CreateCommand()){q.Transaction=tx;q.CommandText="INSERT INTO Invoices(Number,CreatedAt,Cashier,Subtotal,Discount,Total,PaymentMethod,Status) VALUES(@n,@d,@c,@s,@di,@t,@p,'مكتملة'); SELECT last_insert_rowid();";q.Parameters.AddWithValue("@n",number);q.Parameters.AddWithValue("@d",DateTime.Now.ToString("O"));q.Parameters.AddWithValue("@c",cashier);q.Parameters.AddWithValue("@s",subtotal);q.Parameters.AddWithValue("@di",discount);q.Parameters.AddWithValue("@t",total);q.Parameters.AddWithValue("@p",payment);var invoiceId=(long)q.ExecuteScalar()!;foreach(var line in lines){using var item=c.CreateCommand();item.Transaction=tx;item.CommandText="INSERT INTO InvoiceItems(InvoiceId,ProductId,Name,Quantity,UnitPrice) VALUES(@i,@p,@n,@q,@u)";item.Parameters.AddWithValue("@i",invoiceId);item.Parameters.AddWithValue("@p",line.Product.Id);item.Parameters.AddWithValue("@n",line.Product.Name);item.Parameters.AddWithValue("@q",line.Quantity);item.Parameters.AddWithValue("@u",line.Product.Price);item.ExecuteNonQuery();}tx.Commit();return invoiceId;}
    }
    public List<InvoiceSummary> Invoices() { using var c=Open(); using var q=c.CreateCommand(); q.CommandText="SELECT Id,Number,CreatedAt,Total,PaymentMethod,Status FROM Invoices ORDER BY Id DESC"; using var r=q.ExecuteReader(); var list=new List<InvoiceSummary>(); while(r.Read()) list.Add(new InvoiceSummary(r.GetInt64(0),r.GetString(1),DateTime.Parse(r.GetString(2)),Convert.ToDecimal(r.GetDouble(3)),r.GetString(4),r.GetString(5))); return list; }
}
