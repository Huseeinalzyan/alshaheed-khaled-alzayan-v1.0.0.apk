namespace HajNimerAkilaPOS.Models;

public sealed record Product(long Id, string Name, string Category, decimal Price, bool Active = true);
public sealed record CartLine(Product Product, int Quantity);
public sealed record InvoiceSummary(long Id, string Number, DateTime CreatedAt, decimal Total, string PaymentMethod, string Status);
public sealed record InvoiceLine(string Name, int Quantity, decimal UnitPrice);
