using System.Windows;
namespace HajNimerAkilaPOS;
public partial class App : Application
{
    public static string DataDirectory => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "HajNimerAkilaPOS");
    public static string DatabasePath => Path.Combine(DataDirectory, "restaurant.db");
    protected override void OnStartup(StartupEventArgs e)
    {
        Directory.CreateDirectory(DataDirectory);
        base.OnStartup(e);
    }
}
