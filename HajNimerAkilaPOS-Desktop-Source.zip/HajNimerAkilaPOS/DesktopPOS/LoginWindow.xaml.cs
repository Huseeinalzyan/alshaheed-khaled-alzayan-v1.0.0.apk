using System.Windows;
using HajNimerAkilaPOS.Services;
namespace HajNimerAkilaPOS;
public partial class LoginWindow : Window
{
    private readonly DatabaseService _db;
    public string Username => UsernameBox.Text.Trim();
    public LoginWindow(DatabaseService db){InitializeComponent();_db=db;}
    private void Login_Click(object sender,RoutedEventArgs e){if(_db.ValidateLogin(Username,PasswordBox.Password)){DialogResult=true;Close();}else MessageBox.Show("اسم المستخدم أو كلمة المرور غير صحيحة.","فشل تسجيل الدخول",MessageBoxButton.OK,MessageBoxImage.Warning);}
}
