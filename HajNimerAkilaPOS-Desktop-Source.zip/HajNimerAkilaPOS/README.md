# برنامج مطاعم الحاج نمر عكيلة — Windows Desktop POS

هذا المجلد يحتوي على **مصدر برنامج Windows Desktop حقيقي باستخدام C# وWPF**، وليس موقعًا إلكترونيًا. البرنامج يستخدم SQLite محلية ويعمل دون إنترنت.

## المتطلبات على جهاز Windows

- Windows 10 أو Windows 11.
- Visual Studio 2022 مع workload: Desktop development with .NET.
- .NET 8 SDK أو Runtime.
- تعريف طابعة BP-T3 من الشركة المصنعة.

## التشغيل من Visual Studio

1. افتح الملف `DesktopPOS/HajNimerAkilaPOS.csproj`.
2. اختر `HajNimerAkilaPOS` كمشروع بدء التشغيل.
3. اضغط Build ثم Start.
4. بيانات الدخول الأولية: `admin` / `10203090`.

## إنتاج EXE مستقل

من PowerShell داخل مجلد `DesktopPOS`:

```powershell
dotnet restore
dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o .\publish
```

سيظهر الملف التنفيذي داخل `DesktopPOS\publish\HajNimerAkilaPOS.exe`.

## قاعدة البيانات

تُحفظ قاعدة البيانات تلقائيًا في:

`%LOCALAPPDATA%\HajNimerAkilaPOS\restaurant.db`

وذلك لتجنب منع الكتابة داخل `Program Files`. النسخ الاحتياطي من زر «النسخ الاحتياطي» ينسخ ملف SQLite إلى المكان الذي تختاره.

## الطباعة الحرارية

البرنامج يستخدم `PrintDialog` الخاص بـ Windows، وليس طباعة متصفح. ثبّت تعريف BP-T3، اطبع Test Page من Windows أولًا، ثم اختر BP-T3 من نافذة الطباعة واضبط المقاس 58mm أو 80mm. يمكن لاحقًا إضافة RAW/ESC-POS عبر Win32 إذا كان موديل الطابعة يحتاج ذلك.

## نطاق الإصدار الحالي

يحتوي الإصدار على تسجيل الدخول، SQLite، الأصناف الأولية، السلة، الكميات، الخصم، طرق الدفع، حفظ الفواتير داخل Transaction، عرض الفواتير، تقرير إجمالي، نسخ قاعدة البيانات، والطباعة المباشرة من Windows. شاشة إدارة الأصناف المتقدمة والصلاحيات التفصيلية وInstaller الرسومي مراحل لاحقة.
