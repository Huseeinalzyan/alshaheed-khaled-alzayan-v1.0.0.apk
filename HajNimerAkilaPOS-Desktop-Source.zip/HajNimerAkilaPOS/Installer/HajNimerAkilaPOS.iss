; يتطلب Inno Setup على Windows
#define MyAppName "مطاعم الحاج نمر عكيلة POS"
#define MyAppExeName "HajNimerAkilaPOS.exe"
[Setup]
AppName={#MyAppName}
AppVersion=1.0.0
DefaultDirName={autopf}\HajNimerAkilaPOS
DefaultGroupName={#MyAppName}
OutputBaseFilename=HajNimerAkilaPOS-Setup
OutputDir=output
ArchitecturesInstallIn64BitMode=x64
PrivilegesRequired=admin
[Files]
Source: "..\DesktopPOS\publish\*"; DestDir: "{app}"; Flags: recursesubdirs ignoreversion
[Icons]
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{autoprograms}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "تشغيل البرنامج"; Flags: nowait postinstall skipifsilent
